	</div><!-- #content -->

	<!--contact form -->
	<section class="contact-today">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2 class="d-none d-md-block">Take The First Step. <span class="bold-text">Contact Us Today!</span></h2>
					<h2 class="d-block d-md-none">Take The First Step. <br /><span class="bold-text">Contact Us Today!</span></h2>
				</div><!--/col-->
			</div><!--/row-->
			
			<div class="row">
				<div class="col-12 d-flex justify-content-center">
					<form class="form-inline" id="contact-form">
						<div class="form-group mx-md-2 mb-2">
							<label for="fullName" class="sr-only">Name*</label>
							<input type="text" class="form-control" id="fullName" placeholder="Name*">
						</div><!--/form-group-->

						<div class="form-group mx-md-2 mb-2">
							<label for="email" class="sr-only">Email Address*</label>
							<input type="text" class="form-control" id="email" placeholder="Email Address*">
						</div><!--/form-group-->

						<button type="submit" class="d-none d-md-block btn btn-purple mb-2">Submit Form</button>
						<button type="submit" class="d-block d-md-none btn btn-purple mb-2">Start Today</button>
					</form>
				</div><!--/col-->
			</div><!--/row-->
		</div><!--/container-->
	</section>

	<footer class="d-flex">
		<div class="container d-flex">
			<div class="row">
				<div class="col-lg-3 offset-lg-2 col-md-3 offset-md-1 d-flex">
					<div class="footer-logo d-flex align-items-md-center">
						<a href="#"><img class="img-fluid" src="<?php bloginfo('stylesheet_directory');?>/images/purple-bloks-logo-white.png" alt="Footer Logo" /></a>
					</div><!--/footer-logo-->
				</div>

				<div class="col-12 col-md-6 offset-md-1">
					<div class="footer-links">
						<p><span class="extra-bold">Learn</span></p>

						<ul class="nav flex-column flex-md-row">
							<li><a href="#">Contact</a></li>
							<li><a href="#">Support</a></li>
							<li><a href="#">Meet Our Team</a></li>
						</ul>

						<p class="links"><span class="extra-bold">Links</span></p>

						<ul class="nav flex-column flex-md-row">
							<li><a href="#">Products</a></li>
							<li><a href="#">Services</a></li>
						</ul>
					</div><!--/footer-links-->
				</div><!--/col-->
			</div><!--/row-->
		</div><!--container-->
	</footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
