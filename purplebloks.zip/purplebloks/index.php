<?php get_header(); ?>

	<section class="main">
		<div class="container">
			<div class="row">
				<div class="col-12 col-md-4">
					<figure class="figure home-boxes">
						<img class="img-fluid" src="<?php bloginfo('stylesheet_directory'); ?>/images/take-exciting-trips.jpg" alt="Two People High Fiving" />
						<h3 class="text-center">Take Exciting Trips</h3>
					</figure>
				</div><!--/col-->

				<div class="col-12 col-md-4">
					<figure class="figure home-boxes">
						<img class="img-fluid" src="<?php bloginfo('stylesheet_directory'); ?>/images/get-fun-presents.jpg" alt="Man with open present box" />
						<h3 class="text-center">Get Fun Presents</h3>
					</figure>
				</div><!--/col-->

				<div class="col-12 col-md-4">
					<figure class="figure home-boxes last">
						<img class="img-fluid" src="<?php bloginfo('stylesheet_directory'); ?>/images/meet-new-friends.jpg" alt="Guy meeting new alien friend" />
						<h3 class="text-center">Meet New Friends</h3>
					</figure>
				</div><!--/col-->
			</div><!--/row-->
		</div><!--/container-->
	</section>

	<section class="about-logo">
		<div class="container-fluid">
			<div class="row no-gutters">
				<div class="col-12 col-lg-6">
					<div class="about d-flex align-items-lg-center pl-3 pr-3 pl-g-0 pr-md-0">
						<!--<div class="offset-xl-4 offset-lg-0">-->
							<div class="container d-flex justify-content-lg-end mr-xl-4">
							<div class="media d-flex align-items-lg-center p-md-5">
								<img class="img-fluid d-none d-md-block" src="<?php bloginfo('stylesheet_directory'); ?>/images/its-a-piece-of-cake.png" alt="Cake" />

								<div class="media-body">
									<h3>It’s a Piece <br /> of Cake</h3>

									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
								</div><!--/media-body-->
							</div><!--/media-->
						</div><!--about-->
					</div><!--/col-->
				</div><!--/col-->

				<div class="col-12 col-lg-6">
					<div class="purple-bg d-flex">
						<img class="img-fluid align-self-center" src="<?php bloginfo('stylesheet_directory'); ?>/images/purple-bloks-logo-white.png" alt="Logo" />
					</div><!--/purple-bg-->
				</div><!--/div-->
			</div><!--/row-->
		</div><!--container-->
	</section>

<?php
get_footer();
