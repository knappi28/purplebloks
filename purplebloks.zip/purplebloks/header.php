<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<a class="sr-only sr-only-focusable" href="#content"><?php esc_html_e( 'Skip to content', 'purplebloks' ); ?></a>

	 <header>
		 <div class="container">
			 <div class="row">
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="col-8 col-lg-4">
						<a class="navbar-brand" href="#"><img class="img-fluid" src="<?php bloginfo('stylesheet_directory'); ?>/images/purple-bloks-logo.png" alt="Logo" /></a>
					</div>

					<div class="collapse navbar-collapse justify-content-start justify-content-lg-end" id="navbarToggler">
						<?php //wp_nav_menu(array('menu' => 'Main Nav', 'menu_class' => 'navbar-nav mr-auto mt-2 mt-lg-0')); ?>

						<div class="menu-main-nav-container">
							<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
								<li><a href="#">Home</a></li>
								<li><a href="#">About</a></li>
								<li><a href="#">Contact Us</a></li>
							</ul>
						</div><!--/menu-main-nav-container-->
					</div><!--/navbar-collapse-->
				</nav>
			</div><!--/row-->
		</div><!--/container-->
	</header>

	<!--/cta/slider-->
	<div id="home-cta" class="jumbotron jumbotro-fluid d-flex">
		<div class="container d-flex">
			<div class="row">
				<div class="col-12 col-md-6 order-2 order-md-1 align-self-md-center">
					<div class="home-cta-left">
						<img class="img-fluid" src="<?php bloginfo('stylesheet_directory'); ?>/images/purple-bloks-logo-white.png" alt="Logo" />
						<p>It’s Time For A Change.</p>

						<a href="#" class="btn btn-outline-white">Start Today</a>
					</div><!--/home-cta-left-->
				</div><!--/col-->

				<div class="col-12 col-md-6 order-1 order-md-2 d-flex align-items-md-center">
					<div class="home-cta-right">
						<img class="img-fluid" src="<?php bloginfo('stylesheet_directory'); ?>/images/purple-bloks-header-img.png" alt="Sith vs Jedi" />	
					</div><!--/home-cta-right-->
				</div><!--/col-->
			</div><!--row-->
		</div><!--/container-->
	</div><!--/jumbotron-fluid-->

	<!--slogan/cta-->
	<div class="cta-slogan">
		<div class="container">
			<div class="row">
				<div class="col-12 col-md-8">
					<h1 class="d-none d-md-block"><span class="regular-text">Meet New Friends,</span> Have Some Fun.</h1>
					<h1 class="d-block d-md-none"><span class="regular-text">Meet New Friends,</span><br /> Have Some Fun.</h1>
				</div><!--/col-->

				<div class="col-12 col-md-4">
					<a href="#" class="btn btn-outline-purple">Contact Us</a>
				</div><!--/col-->
			</div><!--/row-->
		</div><!--/container-->
	</div><!--/cta-->

	<div id="content">
